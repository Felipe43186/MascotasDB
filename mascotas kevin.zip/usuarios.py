from conexion1 import BaseDatos

class Usuario:
    def __init__(
            self,
            n_documento: int = None,
            nombre: str = None,
            apellido: str = None,
            ciudad: str = None,
            direccion: str = None,
            telefono: str = None,
            es_propietario: bool  = None,
            es_veterinario: bool = None,
            es_administrador: bool = None,
            email: str = None,
            contraseña: str = None
            ):
            self.__n_documento = n_documento
            self.__nombre = nombre
            self.__apellido = apellido
            self.__ciudad = ciudad
            self.__direccion = direccion
            self.__telefono = telefono
            self.__es_propietario = es_propietario
            self.__es_veterinario = es_veterinario
            self.__es_administrador = es_administrador
            self.__email = email
            self.__contraseña = contraseña

    # GET y SET
    def get_n_documento(self):
        return self.__n_documento
    
    def set_n_documento(self):
            while True:
                try:
                    codigo_usuario = int(input('Escriba el código del usuario=>'))
                    if (1 <= codigo_usuario <= 1000000000):
                        self.__n_documento = codigo_usuario
                        break
                    else:
                        print('El número debe estar entre 3 y 100000000')
                except ValueError:
                    print('El código debe ser un número.')
                except KeyboardInterrupt:
                    print('El usuario ha cancelado la entrada de datos.')
                continue
 
    def get_nombre(self):
        return self.__nombre

    def set_nombre(self):
        while True:
            try:
                nombre = input('Nombre del usuario =>')
                if len(nombre)>3:
                    self.__nombre = nombre
                    break
                else:
                    print('Nombre incorrecto. Intente de nuevo')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue

    def get_apellido(self):
        return self.__apellido
    
    def set_apellido(self):
        while True:
            try:
                apellido = input('Apellido del usuario =>')
                if 3 < len(apellido) <= 50:
                    self.__apellido = apellido
                    break
                else:
                    print('Datos incorrectos. Intente de nuevo')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue

    def get_ciudad(self):
        return self.__ciudad
    
    def set_ciudad(self):
        while True:
            try:
                ciudad = input('Ciudad del usuario =>')
                # Verificar que solo contenga letras y espacios y que la longitud esté entre 3 y 30 caracteres
                if 2 < len(ciudad) <= 100:
                    self.__ciudad = ciudad
                    break
                else:
                    print('Datos de raza incorrectos. Intente de nuevo')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue


    
    def get_direccion(self):
        return self.__direccion



    def set_direccion(self):
        while True:
            try:
                direccion = str(input('Direccion del usuario =>'))
                if 0 <= direccion <= 100:
                    self.__direccion = direccion
                    break
                else:
                    print('direccion no válida')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue                

    def get_telefono(self):
        return self.__telefono

    def set_telefono(self):
        while True:
            try:
                telefono = str(input('Telefono del usuario =>'))
                if (1 <= telefono <= 1000):
                    self.__telefono = telefono
                    break
                else:
                    print('telefono no válido')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue                 

    def get_es_propietario(self):
        return self.__es_propietario

    def set_es_propietario(self):
        while True:
            try:
                es_propietario = (input('¿eres propietario? (si o no)=>').strip().lower())
                if es_propietario == 'si' or  es_propietario == 'no':
                    self.__es_propietario = 1
                    break
                elif es_propietario == 'no':    
                    self.__es_propietario = 0
                    break
                else:
                    print('no válido')
                return self.__es_propietario    
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue    

    def get_es_veterinario(self):
        return self.__es_veterinario

    def set_es_veterinario(self):
        while True:
            try:
                es_veterinario = (input('¿eres veterinario? (si o no)=>').strip().lower())
                if es_veterinario == 'si' or  es_veterinario == 'no':
                    self.__es_veterinario = 1
                    break
                elif es_veterinario == 'no':    
                    self.__es_veterinario = 0
                    break
                else:
                    print('no válido')
                return self.__es_veterinario       
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue  

    def get_es_administrador(self):
        return self.__es_administrador

    def set_es_administrador(self):
        while True:
            try:
                es_administrador = (input('¿eres administrador? (si o no)=>').strip().lower())
                if es_administrador== 'si' or  es_administrador == 'no':
                    self.__es_administrador = 1
                    break
                elif es_administrador == 'no':    
                    self.__es_administrador = 0
                    break
                else:
                    print('no válido')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue  

    def get_email(self):
        return self.__email

    def set_email(self):
        while True:
            try:
                email = str(input('Email del usuario =>'))
                if (1 <= email <= 1000):
                    self.__email = email
                    break
                else:
                    print('Email no válido')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue
  
    def get_contraseña(self):
        return self.__contraseña

    def set_contraseña(self):
        while True:
            try:
                contraseña = str(input('Contraseña del usuario =>'))
                if (1 <= contraseña <= 1000):
                    self.__contraseña = contraseña
                    break
                else:
                    print('Contraseña no válido')
            except KeyboardInterrupt:
                print('El usuario ha cancelado la entrada de datos.')
                continue

    def capturar_datos(self):
            self.set_n_documento
            self.set_nombre 
            self.set_apellido
            self.set_ciudad 
            self.set_direccion 
            self.set_telefono 
            self.set_es_propietario 
            self.set_es_veterinario 
            self.set_es_administrador 
            self.set_email
            self.set_contraseña 
