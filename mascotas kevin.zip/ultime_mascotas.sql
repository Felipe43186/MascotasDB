CREATE DATABASE mascotas_db;
USE mascotas_db;
CREATE TABLE usuarios(
n_documento INT UNSIGNED PRIMARY KEY,
nombre VARCHAR(100)NOT NULL,
apellido VARCHAR(100)NOT NULL,
ciudad VARCHAR(100)NOT NULL,
direccion VARCHAR(100)NOT NULL,
telefono VARCHAR(100)NOT NULL,
es_propietario BOOLEAN NOT NULL,
es_veterinario BOOLEAN NOT NULL,
es_administrador BOOLEAN NOT NULL,
email VARCHAR (100)NOT NULL,
contraseña VARCHAR (255)NOT NULL);

CREATE TABLE propietarios(
n_documento INT UNSIGNED PRIMARY KEY,
barrio VARCHAR (100) NOT NULL,
FOREIGN KEY (n_documento) REFERENCES usuarios (n_documento) 
ON DELETE CASCADE
ON UPDATE CASCADE
);
CREATE TABLE mascotas (
codigo  INT UNSIGNED PRIMARY KEY NOT NULL,
nombre VARCHAR (100)NOT NULL,
especie VARCHAR(100) NOT NULL,
raza VARCHAR(100) NOT NULL,
edad DECIMAL (10,2) NOT NULL,
peso DECIMAL (10,2) NOT NULL,
n_documento INT UNSIGNED,
FOREIGN KEY  (n_documento) REFERENCES propietarios(n_documento)
);
 
CREATE TABLE historial_medico(
codigo INT UNSIGNED NOT NULL,
codigo_mascota INT UNSIGNED NOT NULL,
fecha DATE NOT NULL,
descripcion TEXT NOT NULL,
tratamiento TEXT NOT NULL,
PRIMARY KEY (codigo,codigo_mascota),
FOREIGN KEY (codigo_mascota) REFERENCES mascotas(codigo)
ON DELETE CASCADE
ON UPDATE CASCADE);

CREATE TABLE servicios(
codigo INT UNSIGNED PRIMARY KEY NOT NULL,
nombre VARCHAR (100) NOT NULL,
descripcion TEXT NOT NULL,
precio DECIMAL (20,2) NOT NULL);

CREATE TABLE  administradores (
cargo VARCHAR(100)NOT NULL,
fecha_ingreso VARCHAR (100)NOT NULL,
n_documento INT UNSIGNED PRIMARY KEY ,
FOREIGN KEY (n_documento) REFERENCES usuarios (n_documento)
);

CREATE TABLE  veterinarios(
especialidad VARCHAR(100)NOT NULL,
horario VARCHAR(255)NOT NULL,
n_documento INT UNSIGNED ,
FOREIGN KEY (n_documento) REFERENCES usuarios (n_documento)
);

CREATE TABLE productos (
codigo INT UNSIGNED PRIMARY KEY NOT NULL,
nombre VARCHAR (100) NOT NULL,
descripcion TEXT NOT NULL,
precio DECIMAL (20,2) NOT NULL,
stock SMALLINT NOT NULL);

CREATE TABLE citas(
codigo INT UNSIGNED PRIMARY KEY NOT NULL,
fecha DATE,
hora TIME,
id_servicio INT UNSIGNED NOT NULL,
id_veterinario INT UNSIGNED NOT NULL,
id_mascota INT UNSIGNED NOT NULL,
estado ENUM ('PENDIENTE','CONFIRMADO','CANCELADO',' EN ESPERA','DISPONIBLE'),
FOREIGN KEY (id_servicio) REFERENCES servicios (codigo),
FOREIGN KEY (id_veterinario) REFERENCES veterinarios (n_documento),
FOREIGN KEY (id_mascota) REFERENCES mascotas (codigo)
ON DELETE NO ACTION 
ON UPDATE NO ACTION);

DELIMITER //
CREATE PROCEDURE InsertarHistorial(
IN p_codigo INT UNSIGNED,
IN p_codigo_mascota INT UNSIGNED,
IN p_fecha DATE,
IN p_descripcion TEXT,
IN p_tratamiento TEXT)
BEGIN 
INSERT INTO historial_medico(
codigo,
codigo_mascota,
fecha,
descripcion,
tratamiento)
VALUES (
p_codigo,
p_codigo_mascota,
p_fecha,
p_descripcion,
p_tratamiento);
END //
 SELECT * FROM historial_medico;
 DELIMITER //
CREATE PROCEDURE ConsultarPropietarioNombre(
IN p_nombre VARCHAR (100)
)
BEGIN
 SELECT * FROM usuarios WHERE nombre = p_nombre AND es_propietario = TRUE;
 END //

 DELIMITER //
CREATE PROCEDURE ConsultarHistorialId(
IN p_codigo_mascota INT UNSIGNED
)
BEGIN
SELECT 
mascotas.codigo,
mascotas.nombre,
mascotas.especie,
mascotas.raza,
mascotas.edad,
mascotas.peso,
mascotas.n_documento,
historial_medico.codigo,
historial_medico.codigo_mascota,
historial_medico.fecha,
historial_medico.descripcion,
historial_medico.tratamiento
FROM mascotas
JOIN historial_medico  ON mascotas.n_documento = historial_medico.n_documento
WHERE mascotas.n_documento = p_n_documento;
 END //
 
 DELIMITER //
CREATE PROCEDURE ActualizarHistorial(
IN p_codigo INT UNSIGNED,
IN p_codigo_mascota INT UNSIGNED,
IN p_fecha DATE,
IN p_descripcion TEXT,
IN p_tratamiento TEXT)
BEGIN
UPDATE historial_medico
	SET 
	fecha = p_fecha,
	descripcion = p_descripcion,
	tratamiento = P_tratamiento
    WHERE codigo_mascota = p_codigo_mascota AND es_propietario = TRUE;
	END //
    
     DELIMITER //
CREATE PROCEDURE ActualizarCita(
IN p_codigo INT UNSIGNED,
IN p_fecha DATE,
IN p_hora DATE,
IN p_estado VARCHAR (100))
BEGIN
UPDATE citas
	SET 
	fecha = p_fecha,
	hora = p_hora,
	estado = P_estado
    WHERE codigo = p_codigo ;
	END //
    
	DELIMITER //
CREATE PROCEDURE ActualizarServicio(
IN p_codigo INT UNSIGNED,
IN p_nombre VARCHAR(100),
IN p_descripcion TEXT,
IN p_precio DECIMAL (20,2))
BEGIN
UPDATE servicios
	SET 
	nombre = p_nombre,
	descripcion = p_descripcion,
	precio = P_precio
    WHERE codigo = p_codigo ;
	END //
    
DELIMITER //
CREATE PROCEDURE EliminarHistorial(
IN p_codigo INT)
BEGIN 
DELETE FROM  historial_medico WHERE codigo = p_codigo;
END // 
 
 DELIMITER //
CREATE PROCEDURE ConsultarPropietarioId(
IN p_n_documento INT
)
BEGIN
SELECT 
usuarios.n_documento,
usuarios.nombre,
usuarios.apellido,
usuarios.ciudad,
usuarios.direccion,
usuarios.telefono,
usuarios.es_propietario,
usuarios.es_veterinario,
usuarios.es_administrador,
usuarios.email,
usuarios.contraseña,
propietarios.barrio
FROM usuarios
JOIN propietarios  ON usuarios.n_documento = propietarios.n_documento
WHERE usuarios.n_documento = p_n_documento;
 END //
 
 DELIMITER //
 CREATE PROCEDURE TodosPropietarios()
 BEGIN(
	SELECT * FROM usuarios);
 END //
 
DELIMITER //
CREATE PROCEDURE InsertarPropietario(
    IN p_n_documento INT,
    IN p_nombre VARCHAR(100),
    IN p_apellido VARCHAR(100),
    IN p_ciudad VARCHAR(100),
    IN p_direccion VARCHAR(100),
    IN p_barrio VARCHAR(100),
    IN p_telefono VARCHAR(100),
    IN p_es_propietario BOOLEAN,
    IN p_es_veterinario BOOLEAN,
    IN p_es_administrador BOOLEAN,
    IN p_email VARCHAR(100),
    IN p_contraseña VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
-- Deshacer los cambios en la BD si algo falla
ROLLBACK;
        RESIGNAL;
END;
    SET autocommit = 0;
    -- Arrancar la transacción:
    START TRANSACTION;
    -- Insertar en la tabla 'usuarios'
    INSERT INTO usuarios (
		n_documento,
        nombre,
        apellido,
        ciudad,
        direccion,
        telefono,
        es_propietario,
        es_veterinario,
        es_administrador,
        email,
        contraseña)
    VALUES (
p_n_documento,
        p_nombre,
        p_apellido,
        p_ciudad,
        p_direccion,
        p_telefono,
        p_es_propietario,
        p_es_veterinario,
        p_es_administrador,
        p_email,
        p_contraseña);
    -- Insertar en la tabla 'propietarios'
    INSERT INTO propietarios (
		n_documento,
        barrio)
    VALUES (
		p_n_documento,
        p_barrio);
    -- Confirmar la transacción si ambas operaciones son exitosas
    COMMIT;
    SET autocommit = 1;
END //

DELIMITER //
CREATE PROCEDURE ActualizarPropietario(
IN p_n_documento INT,
IN p_nombre VARCHAR(100),
IN p_apellido VARCHAR(100),
IN p_ciudad VARCHAR(100),
IN p_barrio varchar (100),
IN p_direccion VARCHAR(100),
IN p_telefono VARCHAR (100),
IN p_email VARCHAR (100),
IN p_contraseña VARCHAR (255))
BEGIN
UPDATE usuarios
	SET 
	nombre = p_nombre,
	apellido = p_apellido,
	ciudad = P_ciudad,
	barrio = p_barrio,
	direccion = p_direccion,
    telefono = p_telefono,
    email = p_email,
    contraseña = p_contraseña
    WHERE n_documento = p_n_documento AND es_propietario = TRUE;
	END //

DELIMITER //
CREATE PROCEDURE EliminarMascota(
IN p_codigo INT)
BEGIN 
DELETE FROM  mascotas WHERE codigo = p_codigo;
END //

 DELIMITER //
CREATE PROCEDURE EliminarPropietario(
IN p_n_documento INT)
BEGIN 
DELETE FROM  propietarios WHERE n_documento = p_n_documento;
END //


 DELIMITER //
CREATE PROCEDURE InsertarMascota(
IN P_codigo int unsigned,
IN P_nombre varchar(100),
IN P_especie varchar(100) ,
IN P_raza varchar(100) ,
IN P_edad decimal(10,2) ,
IN P_peso decimal(10,2) ,
IN P_n_documento int unsigned
)
BEGIN
INSERT INTO mascotas (
codigo,
nombre,
especie,
raza,
edad,
peso,
n_documento)
VALUES(
p_codigo,
p_nombre,
p_especie,
p_raza,
p_edad,
p_peso,
p_n_documento);

END //
 
DELIMITER //
CREATE PROCEDURE ConsultarMascotaId(
IN p_codigo INT
)
BEGIN
 SELECT * FROM mascotas WHERE codigo = p_codigo;
 END //

 DELIMITER //
CREATE PROCEDURE ConsultarMascotaNombre(
IN p_nombre varchar (100)
)
BEGIN
 SELECT * FROM mascotas WHERE nombre = p_nombre;
 END //
 
 DELIMITER //
 CREATE PROCEDURE TodasMascotas()
 BEGIN(
 SELECT * FROM mascotas);
 END//
 
DELIMITER //
CREATE PROCEDURE ActualizarMascota(
IN p_codigo INT,
IN p_nombre VARCHAR(100),
IN p_especie VARCHAR(100),
IN p_raza VARCHAR(100),
IN p_edad DECIMAL(10,2),
IN p_peso DECIMAL(10,2))
BEGIN
UPDATE mascotas
	SET 
	nombre = p_nombre,
	especie = p_especie,
	raza = P_raza,
	edad = p_edad,
	peso = p_peso
    WHERE codigo = P_codigo;
	END //

DELIMITER //
CREATE PROCEDURE EliminarUsuario(
IN p_n_documento INT)
BEGIN 
DELETE FROM  usuarios WHERE n_documento = p_n_documento;
END //

DELIMITER //
CREATE PROCEDURE InsertarCitas(
    IN p_codigo INT,
    IN p_fecha DATE,
    IN p_hora TIME,
    IN p_id_servicio INT,
    IN p_id_veterinario INT,
    IN p_codigo_mascota INT,
    IN p_estado ENUM('PENDIENTE','CONFIRMADO','CANCELADO',' EN ESPERA','DISPONIBLE')
)
BEGIN
INSERT INTO citas (
codigo,
fecha,
hora,
id_servicio,
id_veterinario,
id_codigo_mascota,
estado)
VALUES(
p_codigo,
p_fecha,
p_hora,
p_id_servicio,
p_id_veterinario,
p_id_codigo_mascota,
p_estado);
END //


 DELIMITER //
CREATE PROCEDURE ConsultarCitaFecha(
IN p_fecha DATE
)
BEGIN
 SELECT * FROM citas WHERE fecha = p_fecha;
 END //

DELIMITER //
CREATE PROCEDURE ConsultarCitaMascota(
IN p_codigo_mascota INT
)
BEGIN
 SELECT * FROM citas WHERE codigo_mascotas = p_codigo_mascotas;
 END //
 
 DELIMITER //
CREATE PROCEDURE ConsultarCitas(
)
BEGIN
 SELECT * FROM citas;
 END //
 
 DELIMITER //
CREATE PROCEDURE EliminarCita(
IN p_codigo INT)
BEGIN 
DELETE FROM  citas WHERE codigo = p_codigo;
END //

 DELIMITER //
CREATE PROCEDURE InsertarServicios(
    IN p_codigo INT,
    IN p_nombre VARCHAR (100),
    IN P_descripcion TEXT,
    IN P_precio decimal (20,2)
    )
BEGIN
INSERT INTO servicios (
codigo,
nombre,
descripcion,
precio
)
VALUES(
p_codigo,
p_nombre,
p_descripcion,
P_precio
);
END //

DELIMITER //
CREATE PROCEDURE ConsultarServicioId(
IN p_codigo INT
)
BEGIN
 SELECT * FROM servicios WHERE codigo = p_codigo;
 END //

DELIMITER //
CREATE PROCEDURE ConsultarServicioNombre(
IN p_nombre INT
)
BEGIN
 SELECT * FROM servicios WHERE nombre = p_nombre;
 END //
 
 DELIMITER //
 CREATE PROCEDURE ConsultarServicios(
)
BEGIN
 SELECT * FROM servicios;
 END //
 
  DELIMITER //
CREATE PROCEDURE EliminarServicio(
IN p_codigo INT)
BEGIN 
DELETE FROM  servicios WHERE codigo = p_codigo;
END //


DELIMITER //
CREATE PROCEDURE InsertarProductos(
    IN p_codigo INT,
    IN p_nombre VARCHAR (100),
    IN P_descripcion TEXT,
    IN P_precio decimal (20,2),
    IN P_stock SMALLINT
    )
BEGIN
INSERT INTO servicios (
codigo,
nombre,
descripcion,
precio,
stock)
VALUES(
p_codigo,
p_nombre,
p_descripcion,
P_precio,
p_stock);
END //

DELIMITER //
CREATE PROCEDURE ConsultarProductosId(
IN p_codigo INT
)
BEGIN
 SELECT * FROM productos WHERE codigo = p_codigo;
 END //
 
 DELIMITER //
CREATE PROCEDURE ConsultarProductosNombre(
IN p_nombre INT
)
BEGIN
 SELECT * FROM productos WHERE nombre = p_nombre;
 END //
 
 DELIMITER //
CREATE PROCEDURE ConsultarProductos(
)
BEGIN
 SELECT * FROM productos;
 END //
 
   DELIMITER //
CREATE PROCEDURE EliminarProducto(
IN p_codigo INT)
BEGIN 
DELETE FROM  productos WHERE codigo = p_codigo;
END //

DELIMITER //
CREATE PROCEDURE InsertarVeterinario(
    IN p_n_documento INT,
    IN p_nombre VARCHAR(100),
    IN p_apellido VARCHAR(100),
    IN p_ciudad VARCHAR(100),
    IN p_direccion VARCHAR(100),
    IN p_telefono VARCHAR(100),
    IN p_especialidad VARCHAR(100),
    IN p_horario VARCHAR(255),
    IN p_es_propietario BOOLEAN,
    IN p_es_veterinario BOOLEAN,
    IN p_es_administrador BOOLEAN,
    IN p_email VARCHAR(100),
    IN p_contraseña VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
ROLLBACK;
        RESIGNAL;
END;
   
    SET autocommit = 0;
   
    START TRANSACTION;
    INSERT INTO usuarios (
n_documento,
        nombre,
        apellido,
        ciudad,
        direccion,
        telefono,
        es_propietario,
        es_veterinario,
        es_administrador,
        email,
        contraseña)
    VALUES (
p_n_documento,
        p_nombre,
        p_apellido,
        p_ciudad,
        p_direccion,
        p_telefono,
        p_es_propietario,
        p_es_veterinario,
        p_es_administrador,
        p_email,
        p_contraseña);
   
    INSERT INTO veterinarios (
n_documento,
        especialidad,
        horario)
    VALUES (
p_n_documento,
        p_especialidad,
        p_horario);

    COMMIT;
    SET autocommit = 1;
END //

DELIMITER //
CREATE PROCEDURE ConsultarVeterinarioNombre (
    IN p_nombre VARCHAR(255)
)
BEGIN
    SELECT
        u.n_documento,
        u.nombre,
        u.apellido,
        u.ciudad,
        u.direccion,
        u.telefono,
        u.es_propietario,
        u.es_veterinario,
        u.es_administrador,
        u.email,
        u.contraseña,
        v.especialidad,
        v.horario
    FROM veterinarios v
    JOIN
        usuarios u ON v.n_documento = u.n_documento
    WHERE
        u.nombre = p_nombre;
END //

DELIMITER //
CREATE PROCEDURE ConsultarVeterinarioId(
    IN p_n_documento INT
)
BEGIN
    SELECT
    u.n_documento,
    u.nombre,
    u.apellido,
    u.ciudad,
    u.direccion,
    u.telefono,
    u.email,
    v.especialidad,
    v.horario
    FROM usuarios u
    JOIN veterinarios v ON u.n_documento = v.n_documento
    WHERE u.n_documento = p_n_documento;
END //

DELIMITER //
CREATE PROCEDURE ConsultarVeterinarios()
BEGIN
    SELECT
        u.n_documento,
        u.nombre,
        u.apellido,
        u.ciudad,
        u.direccion,
        u.telefono,
		u.es_propietario,
        u.es_veterinario,
        u.es_administrador,
        u.email,
        u.contraseña,
        v.especialidad,
        v.horario
    FROM
      veterinarios v
    JOIN
        usuarios u ON v.n_documento = u.n_documento;
END //

DELIMITER //
CREATE PROCEDURE ActualizarVeterinario(
    IN p_n_documento INT,
    IN p_nombre VARCHAR(50),
    IN p_apellido VARCHAR(30),
    IN p_ciudad VARCHAR(50),
    IN p_direccion VARCHAR(100),
    IN p_telefono VARCHAR(20),
    IN p_email VARCHAR(100),
    IN p_contraseña VARCHAR(255),
    IN p_especialidad VARCHAR(100),
    IN p_horario VARCHAR(255)
)
BEGIN
    UPDATE usuarios
    SET nombre = p_nombre,
        apellido = p_apellido,
        ciudad = p_ciudad,
        direccion = p_direccion,
        telefono = p_telefono,
        email = p_email,
        contraseña = p_contraseña
    WHERE n_documento = p_n_documento;
    UPDATE veterinarios
    SET especialidad = p_especialidad,
        horario = p_horario
    WHERE n_documento = p_n_documento;
END //

DELIMITER //
CREATE PROCEDURE EliminarVeterinario(
    IN p_n_documento INT
)
BEGIN
    DELETE FROM veterinarios WHERE n_documento = p_n_documento;
   
    DELETE FROM usuarios WHERE n_documento = p_n_documento;
END //



DELIMITER //
CREATE PROCEDURE InsertarAdministrador(
    IN p_n_documento INT,
    IN p_nombre VARCHAR(100),
    IN p_apellido VARCHAR(100),
    IN p_ciudad VARCHAR(100),
    IN p_direccion VARCHAR(100),
    IN p_telefono VARCHAR(100),
    IN p_especialidad VARCHAR(100),
    IN p_horario VARCHAR(255),
    IN p_es_propietario BOOLEAN,
    IN p_es_veterinario BOOLEAN,
    IN p_es_administrador BOOLEAN,
    IN p_email VARCHAR(100),
    IN p_contraseña VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
ROLLBACK;
        RESIGNAL;
END;
   
    SET autocommit = 0;
   
    START TRANSACTION;
    INSERT INTO usuarios (
n_documento,
        nombre,
        apellido,
        ciudad,
        direccion,
        telefono,
        es_propietario,
        es_veterinario,
        es_administrador,
        email,
        contraseña)
    VALUES (
p_n_documento,
        p_nombre,
        p_apellido,
        p_ciudad,
        p_direccion,
        p_telefono,
        p_es_propietario,
        p_es_veterinario,
        p_es_administrador,
        p_email,
        p_contraseña);
   
    INSERT INTO administradores (
n_documento,
        cargo,
        fecha_ingreso)
    VALUES (
p_n_documento,
        p_cargo,
        p_fecha_ingreso);

    COMMIT;
    SET autocommit = 1;
END //

DELIMITER //
CREATE PROCEDURE ConsultarAdministradorNombre (
    IN p_nombre VARCHAR(255)
)
BEGIN
    SELECT
        u.n_documento,
        u.nombre,
        u.apellido,
        u.ciudad,
        u.direccion,
        u.telefono,
        u.es_propietario,
        u.es_veterinario,
        u.es_administrador,
        u.email,
        u.contraseña,
        a.cargo,
        a.fecha_ingreso
    FROM
        administradores a
    JOIN
        usuarios u ON a.n_documento = u.n_documento
    WHERE
        u.nombre = p_nombre;
END //

DELIMITER //
CREATE PROCEDURE ConsultarAdministradorId(
    IN p_n_documento INT
)
BEGIN
    SELECT
    u.n_documento,
    u.nombre,
    u.apellido,
    u.ciudad,
    u.direccion,
    u.telefono,
    u.email,
    a.cargo,
    a.fecha_ingreso
    FROM usuarios u
    JOIN administradores a ON u.n_documento = a.n_documento
    WHERE u.n_documento= p_n_documento;
END //

DELIMITER //
CREATE PROCEDURE ConsultarAdministradores()
BEGIN
    SELECT
        u.n_documento,
        u.nombre,
        u.apellido,
        u.ciudad,
        u.direccion,
        u.telefono,
		u.es_propietario,
        u.es_veterinario,
        u.es_administrador,
        u.email,
        u.contraseña,
        a.cargo,
        a.fecha_ingreso
    FROM
      administradores a
    JOIN
        usuarios u ON a.n_documento = u.n_documento;
END //

DELIMITER //
CREATE PROCEDURE ActualizarAdministrador(
    IN p_n_documento INT,
    IN p_nombre VARCHAR(50),
    IN p_apellido VARCHAR(30),
    IN p_ciudad VARCHAR(50),
    IN p_direccion VARCHAR(100),
    IN p_telefono VARCHAR(20),
    IN p_email VARCHAR(100),
    IN p_contraseña VARCHAR(255),
    IN p_especialidad VARCHAR(100),
    IN p_horario VARCHAR(255)
)
BEGIN
    UPDATE usuarios
    SET nombre = p_nombre,
        apellido = p_apellido,
        ciudad = p_ciudad,
        direccion = p_direccion,
        telefono = p_telefono,
        email = p_email,
        contraseña = p_contraseña
    WHERE id_usuario = p_id_usuario;
    UPDATE Administraciones
    SET especialidad = p_especialidad,
        horario = p_horario
    WHERE id_usuario = p_id_usuario;
END //

DELIMITER //
CREATE PROCEDURE EliminarAdministradores(
    IN p_id_usuario INT
)
BEGIN
    DELETE FROM administradores WHERE id_usuario = p_id_usuario;
   
    DELETE FROM usuarios WHERE id_usuario = p_id_usuario;
END //

DELIMITER //
CREATE PROCEDURE ActualizarProducto(
IN p_codigo INT,
IN p_nombre VARCHAR(100),
IN p_descripcion VARCHAR(100),
IN p_precio VARCHAR(100),
IN p_stock DECIMAL(10,2))
BEGIN
UPDATE productos
	SET 
	nombre = p_nombre,
	descripcion = p_descripcion,
	precio = P_precio,
	stock = p_stock
    WHERE codigo = P_codigo;
	END //