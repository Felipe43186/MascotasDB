from os import system 
from veterinarios import Veterinarios

class MenuVeterinario:
    @staticmethod
    def menu_veterinario():
        try:
            while True:
                print('\n*************** MENU VETERINARIOS ********************\n')
                print('\t1 - Registrar nuevo veterinario')
                print('\t2 - Consultar veterinario por ID')
                print('\t3 - Consultar veterinario por nombre')
                print('\t4 - Actualizar veterianrio')
                print('\t5 - Eliminar veterinario')
                print('\t6 - Salir del sistema')


                print('\n*************** MENU VETERINARIOS ********************')
                opcion = int(input('\n\tSeleccione una opción: '))
                if opcion == 6:
                    print('Gracias por usar nuestra app..')
                    break

                if opcion == 1:
                    veterinarios = Veterinarios()
                    veterinarios.registrar_veterinario()
                    system('pause')
                    system('cls')

                elif opcion == 2:
                    system('cls')
                    veterinarios = Veterinarios()
                    veterinario = input('Ingrese el ID del veterinario: ')
                    veterinarios.buscar_veterinarioid(veterinario)

                elif opcion == 3:
                    
                    veterinarios = Veterinarios()
                    nombre = input('Ingrese el nombre del veterinario: ')
                    veterinarios.buscar_veterinarionombre(nombre)

                elif opcion == 4:
                    system('cls')
                    veterinarios = Veterinarios()
                    id_veterinario_actualizar = input('Ingrese el ID del veterinario a actualizar: ')
                    veterinarios.actualizar_veterinario(id_veterinario_actualizar)

                elif opcion == 5:
                    system('cls')
                    veterinarios = Veterinarios()
                    id_veterinario_eliminar = input('Ingrese el ID del veterinario a eliminar: ')
                    veterinarios.eliminar_veterinarioid(id_veterinario_eliminar)

        except ValueError:
            print("Error: Ingrese un número válido.")
        
            
if __name__ == "__main__":
    MenuVeterinario.menu_veterinario()
