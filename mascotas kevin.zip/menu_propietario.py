from os import system
from propietarios import Propietarios

class MenuPropietarios:
        @staticmethod
        def main():
            try:
                while True:
                    print('\n*************** MENU PROPIETARIOS ********************\n')

                    print('\t1 -Registrar propietario')
                    print('\t2 -Consultar el propietario por el ID')
                    print('\t3 -Consultar el propietario por el nombre')
                    print('\t4 -Actualizar propietario')
                    print('\t5 -Eliminar propietario')
                    print('\t6 -Salir del sistema')

                    print('\n*************** MENU PROPIETARIO ********************')
                    while True:
                        try:
                            opcion = int(input('\n\tSeleccione una opción: '))
                            break
                        except ValueError:
                            print('Opción no válida')

                    if opcion == 6:
                        print('Gracias por usar nuestra app..')
                        break
                    
                    elif opcion == 1:
                        propietarios = Propietarios()
                        propietarios.registrar_propietario()
                        system('cls')

                    elif opcion == 2:
                        propietarios = Propietarios()
                        propietario = int(input('Ingrese el Id del propietario: '))
                        propietarios.buscar_propietarioid(propietario)
                        system('cls')

                    elif opcion == 3:
                        propietarios = Propietarios()
                        propietario = input('Nombre del propietario: ')
                        propietarios.buscar_propietarionombre(propietario)
                        system('cls')

                    elif opcion == 4:
                        propietarios = Propietarios()
                        propietario = int(input('Id de usuario para actualizar: '))
                        propietarios.actualizar_propietario(propietario)
                        system('cls')

                    elif opcion == 5:
                        propietarios = Propietarios()
                        propietario = input('Ingrese el código del propietario: ')
                        propietarios.eliminar_propietarioid(propietarios)
                        system('cls')

                    else:
                        system('cls')
                        print('Opción no válida. Intente de nuevo')

            except KeyboardInterrupt:
                print('El usuario ha cancelado la ejecución, por favor continue')
            except Exception as error:
                print(f'Ha ocurrido error no codificado {error}')
            finally:
                print('Intente de nuevo')

if __name__ == "__main__":
    MenuPropietarios.main()
